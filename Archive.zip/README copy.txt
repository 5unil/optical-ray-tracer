Modules submitted:

raytracer.py
genpolar.py

To begin import ray tracer and genpolar at terminal.

Then define a simple bundlerays method to iterate over the rtpairs method in genpolar which should create ray objects and store their positions and direction using the append method in raytracer.

Then define refracting surfaces and an output plane object using the SphericalRefraction and OutputPlane classes in raytracer.  

Propagate the rays using the propagate method and use the vertices method to plot spot diagrams and ray diagrams for different situations.